from django.db import models
from django.contrib.auth.models import User
from cryptography.fernet import Fernet
from django.conf import settings
import base64

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to='profile_pictures/', default='default.jpg')

    def __str__(self):
        return self.user.username
    

# class Message(models.Model):
#     sender = models.ForeignKey(User, related_name='sent_messages', on_delete=models.CASCADE)
#     receiver = models.ForeignKey(User, related_name='received_messages', on_delete=models.CASCADE)
#     content = models.TextField()
#     timestamp = models.DateTimeField(auto_now_add=True)
#     is_read = models.BooleanField(default=False)

#     class Meta:
#         ordering = ['timestamp']

#     def encrypt_message(self, message):
#         f = Fernet(settings.ENCRYPTION_KEY)
#         return f.encrypt(message.encode()).decode()

#     def decrypt_message(self, encrypted_message):
#         f = Fernet(settings.ENCRYPTION_KEY)
#         return f.decrypt(encrypted_message.encode()).decode()

#     def save(self, *args, **kwargs):
#         if not self.pk:  # Only encrypt on creation
#             self.content = self.encrypt_message(self.content)
#         super().save(*args, **kwargs)

#     @property
#     def decrypted_content(self):
#         return self.decrypt_message(self.content)

class Message(models.Model):
    sender = models.ForeignKey(User, related_name='sent_messages', on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, related_name='received_messages', on_delete=models.CASCADE)
    content = models.BinaryField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ['timestamp']

    def save(self, *args, **kwargs):
        if isinstance(self.content, str):
            f = Fernet(settings.ENCRYPTION_KEY)
            self.content = f.encrypt(self.content.encode())
        super().save(*args, **kwargs)

    @property
    def decrypted_content(self):
        try:
            f = Fernet(settings.ENCRYPTION_KEY)  
            return f.decrypt(self.content).decode()
        except Exception as e:
            return "Error decrypting message"