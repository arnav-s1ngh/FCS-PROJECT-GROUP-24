from django.urls import path
from .views import (
    initial_page_view, admin_login_view, admin_dashboard_view, register_view, login_view, dashboard_view,
    profile_view, change_profile_picture, change_username, logout_view, send_otp_view, verify_otp_view, inbox, send_message
)

urlpatterns = [
    path('', initial_page_view, name='initial_page'),
    path('admin/login/', admin_login_view, name='admin_login'),
    path('admin/dashboard/', admin_dashboard_view, name='admin_dashboard'),
    path('register/', register_view, name='register'),
    path('login/', login_view, name='login'),
    path('dashboard/', dashboard_view, name='dashboard'),
    path('profile/', profile_view, name='profile'),
    path('profile/change-picture/', change_profile_picture, name='change_profile_picture'),
    path('profile/change-username/', change_username, name='change_username'),
    path('logout/', logout_view, name='logout'),
    path('send-otp/', send_otp_view, name='send_otp'),
    path('verify-otp/<uid>/<token>/', verify_otp_view, name='verify_otp'),
    path('inbox/', inbox, name='inbox'),
    path('send-message/', send_message, name='send_message'),
]