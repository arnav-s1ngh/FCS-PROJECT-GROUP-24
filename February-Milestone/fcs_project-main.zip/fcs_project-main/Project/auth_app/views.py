from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.models import User
from .models import Profile
from .models import Message
from .middlewares import auth, guest
from .forms import CustomUserCreationForm, CustomAuthenticationForm

from django.core.mail import send_mail
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.db.models import Q
from .forms import OTPForm

# Create your views here.

@guest
def initial_page_view(request):
    if request.method == 'POST':
        user_type = request.POST.get('user_type')
        if user_type == 'admin':
            return redirect('admin_login')
        elif user_type == 'user':
            return redirect('login')
    return render(request, 'auth/initial_page.html')

@guest
def admin_login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            if user.is_superuser:
                login(request, user)
                return redirect('admin_dashboard')
            else:
                form.add_error(None, 'You do not have admin privileges')
    else:
        form = AuthenticationForm()
    return render(request, 'auth/admin_login.html', {'form': form})

@auth
def admin_dashboard_view(request):
    if not request.user.is_superuser:
        return redirect('dashboard')
    users = User.objects.all()
    return render(request, 'auth/admin_dashboard.html', {'users': users})

@guest
def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Don't log in user automatically after registration
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'auth/register.html', {'form': form})

@guest
def login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'auth/login.html', {'form': form})

@auth
def dashboard_view(request):
    return render(request, 'dashboard.html')

@auth
def profile_view(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    return render(request, 'profile.html', {'profile': profile})

@auth
def change_profile_picture(request):
    if request.method == 'POST':
        profile_picture = request.FILES.get('profile_picture')
        if profile_picture:
            profile = Profile.objects.get(user=request.user)
            profile.profile_picture = profile_picture
            profile.save()
            return redirect('profile')
    return render(request, 'change_profile_picture.html')

@auth
def change_username(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        if username:
            request.user.username = username
            request.user.save()
            return redirect('profile')
    return render(request, 'change_username.html')

def logout_view(request):
    next_page = request.GET.get('next', 'login')
    logout(request)
    return redirect(next_page)


@guest
def send_otp_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        user = User.objects.filter(email=email).first()
        if user:
            token = default_token_generator.make_token(user)
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            send_mail(
                'Your OTP Code',
                f'Your OTP code is {token}',
                'from@example.com',
                [email],
                fail_silently=False,
            )
            return redirect('verify_otp', uid=uid, token=token)
    return render(request, 'auth/send_otp.html')

# @guest
# def verify_otp_view(request, uid, token):
#     if request.method == 'POST':
#         form = OTPForm(request.POST)
#         if form.is_valid():
#             uid = force_str(urlsafe_base64_decode(uid))
#             user = User.objects.get(pk=uid)
#             if default_token_generator.check_token(user, token):
#                 user.set_password(form.cleaned_data['new_password'])
#                 user.save()
#                 return redirect('login')
#     else:
#         form = OTPForm()
#     return render(request, 'auth/verify_otp.html', {'form': form})

import logging

logger = logging.getLogger(__name__)

@guest
def verify_otp_view(request, uid, token):
    if request.method == 'POST':
        form = OTPForm(request.POST)
        if form.is_valid():
            uid = force_str(urlsafe_base64_decode(uid))
            user = User.objects.get(pk=uid)
            if default_token_generator.check_token(user, token):
                user.set_password(form.cleaned_data['new_password'])
                user.save()
                logger.info(f"Password for user {user.email} has been updated.")
                return redirect('login')
            else:
                logger.error("Invalid token.")
        else:
            logger.error("Form is not valid.")
    else:
        form = OTPForm()
    return render(request, 'auth/verify_otp.html', {'form': form})


@login_required
def inbox(request):
    search_query = request.GET.get('search', '')
    if search_query:
        users = User.objects.filter(
            Q(email__icontains=search_query) | 
            Q(username__icontains=search_query)
        ).exclude(id=request.user.id)
    else:
        users = User.objects.exclude(id=request.user.id)
    
    messages = Message.objects.filter(
        Q(sender=request.user) | 
        Q(receiver=request.user)
    ).order_by('-timestamp')
    
    return render(request, 'messages/inbox.html', {
        'messages': messages,
        'users': users,
        'search_query': search_query
    })

from django.http import JsonResponse

@login_required
def send_message(request):
    if request.method == 'POST':
        receiver_id = request.POST.get('receiver')
        content = request.POST.get('content')
        if receiver_id and content:
            try:
                receiver = User.objects.get(id=receiver_id)
                Message.objects.create(
                    sender=request.user,
                    receiver=receiver,
                    content=content
                )
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'status': 'success'})
            except Exception as e:
                print(f"Error sending message: {e}")
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'status': 'error'}, status=400)
    return redirect('inbox')